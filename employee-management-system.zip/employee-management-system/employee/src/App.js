import React from "react";
import EmployeeDirectory from "./components/EmployeeDirectory";

function App() {
  return (
    <div className="App">
      <EmployeeDirectory />
    </div>
  );
}

export default App;
